import os
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = FastAPI()

app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

@app.get("/")
def map_page(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/loads.geojson")
def get_load_data():
    return FileResponse(os.path.join(BASE_DIR, "static", "loads.geojson"), media_type="application/geo+json")